declare module '*.css';
declare module '*.less';
declare module "*.png";
