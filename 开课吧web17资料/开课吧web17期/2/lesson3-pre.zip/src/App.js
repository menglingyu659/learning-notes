import React from "react";
import ReactReduxPage from "./pages/ReactReduxPage";
import ReactReduxHookPage from "./pages/ReactReduxHookPage";

export default function App(props) {
  return (
    <div>
      {/* <ReactReduxPage /> */}
      <ReactReduxHookPage />
    </div>
  );
}
