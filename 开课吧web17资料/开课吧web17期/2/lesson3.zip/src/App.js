import React from "react";
import RouteComponePage from "./pages/RouteComponePage";

export default function App(props) {
  return (
    <div>
      {/* <HooksPage /> */}

      {/* <ReactReduxPage /> */}
      <RouteComponePage />
    </div>
  );
}
