<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <!-- 使用全局状态 -->
    <p @click="add">{{$store.state.counter.count}}</p>
    <p @click="asyncAdd">{{count}}</p>
    <HelloWorld 
      @add-feature="addFeature"
      msg="Welcome to Your Vue.js + TypeScript App"/>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import HelloWorld from './components/HelloWorld.vue';
import { FeatureSelect } from './types';
import CounterModule from './store/counter'

@Component({
  components: {
    HelloWorld,
  },
})
export default class App extends Vue {
  addFeature(feature: FeatureSelect) {
    console.log('新增了一个特性', feature.name);
    
  }

  get count() {
    return CounterModule.count
  }

  add() {
    CounterModule.add()
  }

  asyncAdd() {
    CounterModule.asyncAdd()
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
