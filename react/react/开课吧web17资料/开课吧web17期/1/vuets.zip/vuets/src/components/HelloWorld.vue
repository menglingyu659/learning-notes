<template>
  <div>
    <h2>{{msg}}</h2>
    <p>
      <input type="text" @keydown.enter="addFeature" />
    </p>
    <div
      v-for="feature in features"
      :key="feature.id"
      :class="{selected: feature.selected}"
    >{{ feature.name }}</div>
    <p>特性总数：{{total}}</p>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Emit, Watch } from "vue-property-decorator";
import { FeatureSelect } from "@/types";
// import axios from 'axios'

@Component
export default class HelloWorld extends Vue {
  @Prop({ type: String, default: "" })
  msg!: string;

  @Prop({ type: String, default: "" })
  msg2!: string;

  // 属性直接做为data使用
  features: FeatureSelect[] = [];

  // 方法名就是事件名
  @Emit()
  addFeature(e: KeyboardEvent) {
    // 类型断言，不是类型转换，是用户判定
    const inp = e.target as HTMLInputElement;
    const feature: FeatureSelect = {
      id: this.features.length + 1,
      name: inp.value,
      selected: false
    };
    this.features.push(feature);
    inp.value = "";

    // 通知父组件, 返回值就是参数
    return feature;
  }

  // 生命周期
  async created() {
    // const resp = await axios.get<FeatureSelect[]>('/api/list')
    const resp = await this.$http.get<FeatureSelect[]>("/api/list");
    this.features = resp.data;
  }

  // 存取器可以转换为计算属性
  get total() {
    return this.features.length;
  }
}
</script>

<style scoped>
.selected {
  background-color: rgb(196, 247, 240);
}
</style>