
export type Feature = {
  id: number,
  name: string,
  version?: string // 可选属性
}

export type Select = {
  selected: boolean
}

export type FeatureSelect = Feature & Select