// 类型注解
let var1: string;
var1 = '开课吧'
// var1 = 1

// 类型推断
let var2 = true;
// var2 = 'abc'

// 常见类型：string, number, boolean, undefined, null, symbol
let var3: string | null;

// 任意类型
let var4: any;

// 类型数组
let arr: string[]
arr = ['tom']

// 任意类型结合数组
let arrAny: any[]
arrAny = [1, true, 'free']

// 函数中的类型约束
function greet(person: string): string {
  return 'hello '+ person
}
greet('tom')


function warn():void {}



let objType: {foo: string, bar: string}
objType = {foo:'fooo', bar:'barr'}
objType.foo

// 类型别名：自定义类型
type Foobar = {foo: string, bar: string}

let aliasType: Foobar


// 函数
// 1.必选参数:只要声明就要传递
// 2.可选参数：加上问号即可
// 3.默认值
function greeting(person: string, msg: string = '', age?:number): string {
  return person + msg
}


// 03-class.ts
class Parent {
  private _foo = "foo"; // 私有属性，不能在类的外部访问
  protected bar = "bar"; // 保护属性，可以在子类中访问

  // 参数属性：构造函数参数加修饰符，能够定义为成员属性
  constructor(public tua = "tua") {}

  // 方法也有修饰符
  private someMethod() {}

  // 存取器：属性方式访问，可添加额外逻辑，控制读写性
  get foo() {
    return this._foo;
  }
  set foo(val) {
    this._foo = val;
  }
}
class Child extends Parent {
  log() {
    this.bar
  }
}
new Parent()
new Child()