describe('renderer: element', () => {
  test.todo('with props')

  test.todo('with direct text children')

  test.todo('with text node children')

  test.todo('handle already mounted VNode')
})
