import React, {useState, useEffect} from "react";

// import Button from "antd/es/button";
// import "antd/dist/antd.css";

import {Button} from "antd";

export default function App(props) {
  return (
    <div>
      <h3>App</h3>
      <Button type="primary"> click</Button>
      <a href="https://www.kaikeba.com/">kaiekba</a>
    </div>
  );
}
