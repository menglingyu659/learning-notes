// class Component {
//   static isReactComponent = {};
//   constructor(props) {
//     this.props = props;
//   }
// }

// todo
function Component(props) {
  this.props = props;
}

Component.prototype.isReactComponent = {};

export default Component;
