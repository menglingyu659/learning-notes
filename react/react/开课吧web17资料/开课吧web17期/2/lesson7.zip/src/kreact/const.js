export const TEXT = "TEXT";
