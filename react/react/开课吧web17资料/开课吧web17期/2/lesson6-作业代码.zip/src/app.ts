// export const layout = {
//   logout: () => {}, // do something
//   rightRender: initInfo => {
//     return 'hahah';
//   }, // return string || ReactNode;
// };
