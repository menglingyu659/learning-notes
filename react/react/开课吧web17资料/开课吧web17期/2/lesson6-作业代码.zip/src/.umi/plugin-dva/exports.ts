
export { connect, useDispatch, useStore, useSelector } from '/Users/gaoshaoyun/workspace/kkb-react/lesson6-more/node_modules/dva';
export { getApp as getDvaApp } from './dva';
