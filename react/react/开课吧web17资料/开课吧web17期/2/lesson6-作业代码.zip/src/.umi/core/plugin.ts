import { Plugin } from '/Users/gaoshaoyun/workspace/kkb-react/lesson6-more/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['patchRoutes','rootContainer','render','onRouteChange','dva','getInitialState','layout','request',],
});
plugin.register({
  apply: require('/Users/gaoshaoyun/workspace/kkb-react/lesson6-more/src/app.ts'),
  path: '/Users/gaoshaoyun/workspace/kkb-react/lesson6-more/src/app.ts',
});
plugin.register({
  apply: require('/Users/gaoshaoyun/workspace/kkb-react/lesson6-more/src/.umi/plugin-dva/runtime.tsx'),
  path: '/Users/gaoshaoyun/workspace/kkb-react/lesson6-more/src/.umi/plugin-dva/runtime.tsx',
});
plugin.register({
  apply: require('../plugin-initial-state/runtime'),
  path: '../plugin-initial-state/runtime',
});
plugin.register({
  apply: require('@@/plugin-layout/runtime.tsx'),
  path: '@@/plugin-layout/runtime.tsx',
});
plugin.register({
  apply: require('../plugin-model/runtime'),
  path: '../plugin-model/runtime',
});
plugin.register({
  apply: require('/Users/gaoshaoyun/workspace/kkb-react/lesson6-more/node_modules/umi-plugin-antd-icon-config/lib/app.js'),
  path: '/Users/gaoshaoyun/workspace/kkb-react/lesson6-more/node_modules/umi-plugin-antd-icon-config/lib/app.js',
});

export { plugin };
