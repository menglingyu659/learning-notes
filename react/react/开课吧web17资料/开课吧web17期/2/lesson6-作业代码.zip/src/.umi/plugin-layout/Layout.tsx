import React from 'react';
import { ApplyPluginsType } from 'umi';
import { plugin } from '../core/umiExports';

export default (props) => {
  const runtimeConfig = plugin.applyPlugins({
    key: 'layout',
    type: ApplyPluginsType.modify,
    initialValue: {},
  }) || {};
  const userConfig = {
    ...{'name':'开课吧','theme':'PRO','locale':false,'showBreadcrumb':true,'logo':'https://img.kaikeba.com/web/kkb_index/img_index_logo.png'},
    ...runtimeConfig
  };
  return React.createElement(require('/Users/gaoshaoyun/workspace/kkb-react/lesson6-more/node_modules/@umijs/plugin-layout/lib/layout/index.js').default, {
    userConfig,
    ...props
  })
}
