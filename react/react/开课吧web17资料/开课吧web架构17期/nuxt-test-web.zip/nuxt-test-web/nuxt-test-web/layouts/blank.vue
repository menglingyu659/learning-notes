<template>
  <div>
    <nuxt></nuxt>
  </div>
</template>