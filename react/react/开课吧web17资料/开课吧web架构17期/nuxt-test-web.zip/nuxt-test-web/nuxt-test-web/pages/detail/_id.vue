<template>
  <div>
    
    {{$route.params.id}}
  </div>
</template>

<script>
export default {

};
</script>