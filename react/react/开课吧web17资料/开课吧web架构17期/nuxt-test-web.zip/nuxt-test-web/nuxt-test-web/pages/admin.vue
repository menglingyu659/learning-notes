<template>
  <div>
    <h2>admin page</h2>
    
  </div>
</template>

<script>
export default {
  middleware: ['auth']
};
</script>