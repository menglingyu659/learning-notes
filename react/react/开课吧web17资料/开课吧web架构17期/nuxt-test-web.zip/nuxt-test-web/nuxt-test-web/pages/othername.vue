<template>
  <div>
    foo page
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style lang="scss" scoped>

</style>